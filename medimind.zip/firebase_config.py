firebase_config = {
    "apiKey": "AIzaSyDpgucWAeY0Y2CnTi5QgIJGHS1UaEAJEDE",
    "authDomain": "medimind-fc2a6.firebaseapp.com",
    "projectId": "medimind-fc2a6",
    "databaseURL": "https://medimind-fc2a6-default-rtdb.firebaseio.com",
    "storageBucket": "medimind-fc2a6.appspot.com",
    "messagingSenderId": "557894168058",
    "appId": "1:557894168058:web:068c294117bf6f5a7c0843",
    "measurementId": "G-XDFY5TF24J"
}
